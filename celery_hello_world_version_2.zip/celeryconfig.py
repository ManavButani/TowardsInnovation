from celery.schedules import crontab

beat_schedule = {
    'say-hello-every-minute': {
        'task': 'tasks.say_hello',
        'schedule': crontab(),  # every minute
    },
}

timezone = 'UTC'
broker_url = 'redis://localhost:6379/0'
# result_backend = 'db+sqlite:///results.sqlite3'
