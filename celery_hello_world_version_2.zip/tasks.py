from celery import Celery, signals
from task_logger import init_db, log_task_prerun, log_task_postrun, log_task_failure

app = Celery('hello_world')
app.config_from_object('celeryconfig')

init_db()  # Ensure table is ready

@app.task(bind=True, name="tasks.say_hello")
def say_hello(self):
    print("Hello, World!")
    return "Printed successfully"

@signals.task_prerun.connect
def task_prerun_handler(sender=None, task_id=None, task=None, args=None, kwargs=None, **extras):
    log_task_prerun(task_id, task.name, args, kwargs)

@signals.task_postrun.connect
def task_postrun_handler(sender=None, task_id=None, retval=None, **extras):
    log_task_postrun(task_id, retval)

@signals.task_failure.connect
def task_failure_handler(sender=None, task_id=None, exception=None, **extras):
    log_task_failure(task_id, exception)
