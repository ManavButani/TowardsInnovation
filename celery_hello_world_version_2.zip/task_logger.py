# celery_hello_world/task_logger.py

import datetime
import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent / "task_logs.sqlite3"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS celery_tasklog (
                id TEXT PRIMARY KEY,
                name TEXT,
                args TEXT,
                kwargs TEXT,
                status TEXT,
                result TEXT,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
        ''')

def log_task_prerun(task_id, name, args, kwargs):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            INSERT OR REPLACE INTO celery_tasklog (id, name, args, kwargs, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            task_id,
            name,
            json.dumps(args),
            json.dumps(kwargs),
            'STARTED',
            datetime.datetime.utcnow(),
            datetime.datetime.utcnow(),
        ))

def log_task_postrun(task_id, result):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            UPDATE celery_tasklog
            SET status = ?, result = ?, updated_at = ?
            WHERE id = ?
        ''', (
            'SUCCESS',
            str(result),
            datetime.datetime.utcnow(),
            task_id,
        ))

def log_task_failure(task_id, exc):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            UPDATE celery_tasklog
            SET status = ?, result = ?, updated_at = ?
            WHERE id = ?
        ''', (
            'FAILURE',
            str(exc),
            datetime.datetime.utcnow(),
            task_id,
        ))
