# Celery Hello World App

This is a minimal Celery app that prints "Hello, World!" every minute using Celery Beat.

## Requirements

- Python 3.8+
- Redis (as a message broker)

## Installation

```bash
git clone <repo_url>  # Or unzip this folder
cd celery_hello_world
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Start Redis (if not already running)

Make sure Redis is running locally on port 6379.  
You can install it via:

### macOS:
```bash
brew install redis
brew services start redis
```

### Ubuntu/Debian:
```bash
sudo apt install redis
sudo systemctl start redis
```

### Windows:
Download and run from https://github.com/tporadowski/redis/releases

## Run the Celery app

In one terminal:
```bash
celery -A tasks worker --loglevel=info
```

In another terminal:
```bash
celery -A tasks beat --loglevel=info
```

You should see "Hello, World!" printed every minute in the worker terminal.

## File Structure

```
celery_hello_world/
├── celeryconfig.py
├── requirements.txt
├── tasks.py
├── README.md
```