from celery.schedules import crontab

beat_schedule = {
    'say-good-morning': {
        'task': 'tasks.good_morning',
        'schedule': crontab(),  # every 1 minute
    },
    'say-good-night': {
        'task': 'tasks.good_night',
        'schedule': crontab(minute='*/2'),  # every 2 minutes
    },
}

timezone = 'UTC'
broker_url = 'redis://localhost:6379/0'
# result_backend = 'db+sqlite:///results.sqlite3'