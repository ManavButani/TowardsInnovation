import datetime
import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent / "run_metadata.sqlite3"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS task_schedule (
                name TEXT PRIMARY KEY,
                frequency TEXT
            )
        ''')
        conn.execute('''
            INSERT OR IGNORE INTO task_schedule (name, frequency) VALUES
            ('tasks.good_morning', 'every 1 minute'),
            ('tasks.good_night', 'every 2 minutes')
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS run_record (
                id TEXT PRIMARY KEY,
                name TEXT,
                args TEXT,
                kwargs TEXT,
                status TEXT,
                result TEXT,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
        ''')

def log_task_prerun(task_id, name, args, kwargs):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            INSERT OR REPLACE INTO run_record (id, name, args, kwargs, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            task_id,
            name,
            json.dumps(args),
            json.dumps(kwargs),
            'STARTED',
            datetime.datetime.utcnow(),
            datetime.datetime.utcnow(),
        ))

def log_task_postrun(task_id, result):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            UPDATE run_record
            SET status = ?, result = ?, updated_at = ?
            WHERE id = ?
        ''', (
            'SUCCESS',
            str(result),
            datetime.datetime.utcnow(),
            task_id,
        ))

def log_task_failure(task_id, exc):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            UPDATE run_record
            SET status = ?, result = ?, updated_at = ?
            WHERE id = ?
        ''', (
            'FAILURE',
            str(exc),
            datetime.datetime.utcnow(),
            task_id,
        ))