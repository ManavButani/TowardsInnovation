from celery import shared_task, signals
from celery_hello_world.task_logger import log_task_prerun, log_task_postrun, log_task_failure

@shared_task(bind=True, name="tasks.good_morning")
def good_morning(self):
    print("Good Morning!")
    return "Good Morning run successful"

@shared_task(bind=True, name="tasks.good_night")
def good_night(self):
    print("Good Night!")
    return "Good Night run successful"

@signals.task_prerun.connect
def task_prerun_handler(sender=None, task_id=None, task=None, args=None, kwargs=None, **extras):
    log_task_prerun(task_id, task.name, args, kwargs)

@signals.task_postrun.connect
def task_postrun_handler(sender=None, task_id=None, retval=None, **extras):
    log_task_postrun(task_id, retval)

@signals.task_failure.connect
def task_failure_handler(sender=None, task_id=None, exception=None, **extras):
    log_task_failure(task_id, exception)