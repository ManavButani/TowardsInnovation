from celery import Celery
from celery_hello_world.task_logger import init_db

# Create the Celery app
app = Celery('celery_hello_world')
app.config_from_object('celery_hello_world.celeryconfig')

# ✅ IMPORTANT: Import the tasks here to register them with the worker
import celery_hello_world.tasks

# Initialize the DB (optional for your tracking setup)
init_db()
