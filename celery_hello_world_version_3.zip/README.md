### 3. Run Celery Worker

```bash
celery -A celery_hello_world.celery worker --loglevel=info
```

### 4. In another terminal, run Celery Beat

```bash
celery -A celery_hello_world.celery beat --loglevel=info
```

## ✅ Scheduled Tasks

- `good_morning`: Runs every 1 minute.
- `good_night`: Runs every 2 minutes.

## 📊 Task Tracking Tables

A custom SQLite DB named `run_metadata.sqlite3` contains:

### task_schedule

| name              | frequency        |
|-------------------|------------------|
| tasks.good_morning | every 1 minute   |
| tasks.good_night   | every 2 minutes  |

### run_record

| Column     | Description                    |
|------------|--------------------------------|
| id         | Task ID                        |
| name       | Task name                      |
| args       | Positional arguments (JSON)    |
| kwargs     | Keyword arguments (JSON)       |
| status     | STARTED, SUCCESS, FAILURE      |
| result     | Return value or exception      |
| created_at | Time task was scheduled        |
| updated_at | Time task was updated          |

## 🔍 View Run Records

```bash
sqlite3 run_metadata.sqlite3
SELECT * FROM run_record;
```

## 🧪 Manual Trigger (Optional)

```python
from tasks import good_morning
good_morning.delay()
```