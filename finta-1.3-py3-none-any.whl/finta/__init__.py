from finta.finta import TA
